package com.example.musicapp.ui.screens

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.musicapp.data.model.Genre
import com.example.musicapp.ui.MusicViewModel
import com.example.musicapp.ui.components.SongRow

@Composable
fun GenresScreen(viewModel: MusicViewModel) {
    var selectedGenre by remember { mutableStateOf<Genre?>(null) }

    when {
        !viewModel.hasPermission -> PermissionMessage("Audio permission is required to load genres.")
        viewModel.isLoading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        selectedGenre != null -> {
            val genre = selectedGenre!!
            val genreSongs = viewModel.songs.filter { it.genre == genre.name }
            Column(Modifier.fillMaxSize()) {
                Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { selectedGenre = null }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                    Spacer(Modifier.width(4.dp))
                    Column {
                        Text(genre.name, style = MaterialTheme.typography.titleLarge)
                        Text("${genre.songCount} songs", style = MaterialTheme.typography.bodySmall)
                    }
                }
                LazyColumn(Modifier.fillMaxSize()) {
                    items(genreSongs, key = { it.id }) { song ->
                        SongRow(song = song, onClick = { viewModel.playSong(song, genreSongs) })
                    }
                }
            }
        }
        else -> Column(Modifier.fillMaxSize()) {
            Text("Genres (${viewModel.genres.size})", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.padding(16.dp))
            LazyColumn(Modifier.fillMaxSize()) {
                items(viewModel.genres, key = { it.name }) { genre ->
                    CategoryRow(
                        title = genre.name,
                        subtitle = "${genre.songCount} songs",
                        onClick = { selectedGenre = genre },
                    )
                }
            }
        }
    }
}
