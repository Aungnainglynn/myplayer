package com.example.musicapp.editor

import android.content.ContentValues
import android.content.Context
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.media.MediaMuxer
import android.os.Build
import android.provider.MediaStore
import java.io.File
import java.nio.ByteBuffer

object AudioEditor {

    data class TrimResult(val outputPath: String)

    fun trimAudio(
        context: Context,
        inputPath: String,
        startMs: Long,
        endMs: Long,
        outputName: String,
    ): TrimResult {
        require(endMs > startMs) { "End time must be after start time." }
        val extractor = MediaExtractor()
        extractor.setDataSource(inputPath)

        val audioTrackIndex = (0 until extractor.trackCount).firstOrNull { i ->
            val mime = extractor.getTrackFormat(i).getString(MediaFormat.KEY_MIME).orEmpty()
            mime.startsWith("audio/")
        } ?: run {
            extractor.release()
            throw IllegalArgumentException("No audio track found in selected file.")
        }

        val format = extractor.getTrackFormat(audioTrackIndex)
        val mime = format.getString(MediaFormat.KEY_MIME).orEmpty()
        val outputExt = if (mime.contains("mp4") || mime.contains("aac") || mime.contains("m4a")) "m4a" else "m4a"

        val outputFile = createOutputFile(context, outputName, outputExt)
        val muxer = MediaMuxer(outputFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)

        try {
            extractor.selectTrack(audioTrackIndex)
            val muxTrack = muxer.addTrack(format)
            muxer.start()

            extractor.seekTo(startMs * 1000, MediaExtractor.SEEK_TO_CLOSEST_SYNC)
            val bufferSize = if (format.containsKey(MediaFormat.KEY_MAX_INPUT_SIZE)) {
                format.getInteger(MediaFormat.KEY_MAX_INPUT_SIZE)
            } else {
                256 * 1024
            }
            val buffer = ByteBuffer.allocate(bufferSize)
            val info = android.media.MediaCodec.BufferInfo()

            while (true) {
                info.offset = 0
                info.size = extractor.readSampleData(buffer, 0)
                if (info.size < 0) break

                val sampleTimeUs = extractor.sampleTime
                if (sampleTimeUs < 0) break
                if (sampleTimeUs > endMs * 1000) break

                info.presentationTimeUs = sampleTimeUs - (startMs * 1000)
                if (info.presentationTimeUs < 0) {
                    extractor.advance()
                    continue
                }
                info.flags = if (extractor.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC != 0) {
                    android.media.MediaCodec.BUFFER_FLAG_KEY_FRAME
                } else {
                    0
                }
                muxer.writeSampleData(muxTrack, buffer, info)
                extractor.advance()
            }
        } finally {
            try { muxer.stop() } catch (_: Exception) {}
            muxer.release()
            extractor.release()
        }

        publishToMediaStore(context, outputFile)
        return TrimResult(outputFile.absolutePath)
    }

    fun getDurationMs(path: String): Long {
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(path)
            retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        } finally {
            retriever.release()
        }
    }

    private fun createOutputFile(context: Context, outputName: String, ext: String): File {
        val safeName = outputName.replace(Regex("[^a-zA-Z0-9._-]"), "_").ifBlank { "edited_audio" }
        val dir = File(context.getExternalFilesDir("edited"), "").apply { mkdirs() }
        return File(dir, "$safeName.${ext}")
    }

    private fun publishToMediaStore(context: Context, file: File) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return
        val values = ContentValues().apply {
            put(MediaStore.Audio.Media.DISPLAY_NAME, file.name)
            put(MediaStore.Audio.Media.MIME_TYPE, "audio/mp4")
            put(MediaStore.Audio.Media.RELATIVE_PATH, "Music/MusicAppEdits")
            put(MediaStore.Audio.Media.IS_MUSIC, 1)
        }
        val resolver = context.contentResolver
        val uri = resolver.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, values) ?: return
        resolver.openOutputStream(uri)?.use { out ->
            file.inputStream().use { input -> input.copyTo(out) }
        }
    }
}
