package com.example.musicapp.ui

import android.app.Application
import android.content.ComponentName
import androidx.compose.runtime.getStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setStateOf
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.example.musicapp.data.model.Album
import com.example.musicapp.data.model.Genre
import com.example.musicapp.data.model.MusicFolder
import com.example.musicapp.data.model.Song
import com.example.musicapp.data.repository.MusicRepository
import com.example.musicapp.player.PlaybackService
import com.google.common.util.concurrent.ListenableFuture
import com.google.common.util.concurrent.MoreExecutors
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MusicViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = MusicRepository(application)
    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var controller: MediaController? = null
    private var progressJob: Job? = null

    var songs by mutableStateOf<List<Song>>(emptyList())
        private set
    var albums by mutableStateOf<List<Album>>(emptyList())
        private set
    var genres by mutableStateOf<List<Genre>>(emptyList())
        private set
    var folders by mutableStateOf<List<MusicFolder>>(emptyList())
        private set

    var isLoading by mutableStateOf(false)
        private set
    var hasPermission by mutableStateOf(false)
        private set

    var currentSong by mutableStateOf<Song?>(null)
        private set
    var isPlaying by mutableStateOf(false)
        private set
    var progressMs by mutableStateOf(0L)
        private set
    var durationMs by mutableStateOf(0L)
        private set

    private val playerListener = object : Player.Listener {
        override fun onIsPlayingChanged(playing: Boolean) {
            isPlaying = playing
        }

        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            updateCurrentFromController()
        }

        override fun onPlaybackStateChanged(playbackState: Int) {
            updateCurrentFromController()
        }
    }

    init {
        connectController()
    }

    fun onPermissionResult(granted: Boolean) {
        hasPermission = granted
        if (granted) refreshLibrary()
    }

    fun refreshLibrary() {
        viewModelScope.launch {
            isLoading = true
            val loaded = withContext(Dispatchers.IO) { repository.loadSongs() }
            songs = loaded
            albums = repository.buildAlbums(loaded)
            genres = repository.buildGenres(loaded)
            folders = repository.buildFolders(loaded)
            isLoading = false
        }
    }

    fun playSong(song: Song, queue: List<Song> = songs) {
        val c = controller ?: return
        val index = queue.indexOfFirst { it.id == song.id }.coerceAtLeast(0)
        val items = queue.map { it.toMediaItem() }
        c.setMediaItems(items, index, 0L)
        c.prepare()
        c.play()
        currentSong = song
    }

    fun togglePlayPause() {
        val c = controller ?: return
        if (c.isPlaying) c.pause() else c.play()
    }

    fun next() {
        controller?.seekToNextMediaItem()
    }

    fun previous() {
        val c = controller ?: return
        if (c.currentPosition > 3000) c.seekTo(0) else c.seekToPreviousMediaItem()
    }

    fun seekTo(positionMs: Long) {
        controller?.seekTo(positionMs)
        progressMs = positionMs
    }

    private fun connectController() {
        val app = getApplication<Application>()
        val token = SessionToken(app, ComponentName(app, PlaybackService::class.java))
        val future = MediaController.Builder(app, token).buildAsync()
        controllerFuture = future
        future.addListener({
            val c = future.get()
            controller = c
            c.addListener(playerListener)
            startProgressUpdates()
            updateCurrentFromController()
        }, MoreExecutors.directExecutor())
    }

    private fun startProgressUpdates() {
        progressJob?.cancel()
        progressJob = viewModelScope.launch {
            while (true) {
                controller?.let {
                    progressMs = it.currentPosition.coerceAtLeast(0L)
                    durationMs = it.duration.coerceAtLeast(0L)
                }
                delay(500)
            }
        }
    }

    private fun updateCurrentFromController() {
        val c = controller ?: return
        val mediaId = c.currentMediaItem?.mediaId?.toLongOrNull()
        if (mediaId != null) {
            currentSong = songs.find { it.id == mediaId } ?: currentSong
        }
        durationMs = c.duration.coerceAtLeast(0L)
        progressMs = c.currentPosition.coerceAtLeast(0L)
        isPlaying = c.isPlaying
    }

    private fun Song.toMediaItem(): MediaItem {
        return MediaItem.Builder()
            .setMediaId(id.toString())
            .setUri(contentUri)
            .setMediaMetadata(
                MediaMetadata.Builder()
                    .setTitle(title)
                    .setArtist(artist)
                    .setAlbumTitle(album)
                    .setArtworkUri(albumArtUri)
                    .build()
            )
            .build()
    }

    override fun onCleared() {
        progressJob?.cancel()
        controller?.removeListener(playerListener)
        controllerFuture?.let { MediaController.releaseFuture(it) }
        super.onCleared()
    }
}
