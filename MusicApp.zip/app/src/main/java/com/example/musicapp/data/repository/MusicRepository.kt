package com.example.musicapp.data.repository

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import com.example.musicapp.data.model.Album
import com.example.musicapp.data.model.Genre
import com.example.musicapp.data.model.MusicFolder
import com.example.musicapp.data.model.Song
import java.io.File

class MusicRepository(private val context: Context) {

    fun loadSongs(): List<Song> {
        val genreMap = loadGenreMap()
        val songs = mutableListOf<Song>()
        val collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        } else {
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        }

        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.ALBUM_ID,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.DATA,
        )

        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0"
        val sortOrder = "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"

        context.contentResolver.query(collection, projection, selection, null, sortOrder)?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val albumCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
            val albumIdCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
            val durationCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            val dataCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA)

            while (cursor.moveToNext()) {
                val id = cursor.getLong(idCol)
                val title = cursor.getString(titleCol).orEmpty().ifBlank { "Unknown Title" }
                val artist = cursor.getString(artistCol).orEmpty().let {
                    if (it.isBlank() || it == "<unknown>") "Unknown Artist" else it
                }
                val album = cursor.getString(albumCol).orEmpty().let {
                    if (it.isBlank() || it == "Music") "Unknown Album" else it
                }
                val albumId = cursor.getLong(albumIdCol)
                val duration = cursor.getLong(durationCol)
                val path = cursor.getString(dataCol).orEmpty()
                val folderPath = File(path).parent ?: ""
                val folderName = File(folderPath).name.ifBlank { "Unknown Folder" }
                val contentUri = ContentUris.withAppendedId(collection, id)
                val albumArtUri = ContentUris.withAppendedId(
                    Uri.parse("content://media/external/audio/albumart"),
                    albumId
                )

                songs += Song(
                    id = id,
                    title = title,
                    artist = artist,
                    album = album,
                    albumId = albumId,
                    genre = genreMap[id] ?: "Unknown Genre",
                    durationMs = duration,
                    path = path,
                    folder = folderName,
                    contentUri = contentUri,
                    albumArtUri = albumArtUri,
                )
            }
        }
        return songs
    }

    private fun loadGenreMap(): Map<Long, String> {
        val map = mutableMapOf<Long, String>()
        val genreUri = MediaStore.Audio.Genres.EXTERNAL_CONTENT_URI
        val genreProjection = arrayOf(
            MediaStore.Audio.Genres._ID,
            MediaStore.Audio.Genres.NAME,
        )

        context.contentResolver.query(genreUri, genreProjection, null, null, null)?.use { genreCursor ->
            val idCol = genreCursor.getColumnIndexOrThrow(MediaStore.Audio.Genres._ID)
            val nameCol = genreCursor.getColumnIndexOrThrow(MediaStore.Audio.Genres.NAME)
            while (genreCursor.moveToNext()) {
                val genreId = genreCursor.getLong(idCol)
                val genreName = genreCursor.getString(nameCol).orEmpty().ifBlank { "Unknown Genre" }
                val membersUri = MediaStore.Audio.Genres.Members.getContentUri("external", genreId)
                context.contentResolver.query(
                    membersUri,
                    arrayOf(MediaStore.Audio.Genres.Members.AUDIO_ID),
                    null,
                    null,
                    null
                )?.use { memberCursor ->
                    val audioIdCol = memberCursor.getColumnIndexOrThrow(MediaStore.Audio.Genres.Members.AUDIO_ID)
                    while (memberCursor.moveToNext()) {
                        map[memberCursor.getLong(audioIdCol)] = genreName
                    }
                }
            }
        }
        return map
    }

    fun buildAlbums(songs: List<Song>): List<Album> =
        songs.groupBy { it.albumId }.map { (albumId, items) ->
            val first = items.first()
            Album(
                id = albumId,
                name = first.album,
                artist = first.artist,
                songCount = items.size,
                artUri = first.albumArtUri,
            )
        }.sortedBy { it.name.lowercase() }

    fun buildGenres(songs: List<Song>): List<Genre> =
        songs.groupBy { it.genre }.map { (name, items) ->
            Genre(name = name, songCount = items.size)
        }.sortedBy { it.name.lowercase() }

    fun buildFolders(songs: List<Song>): List<MusicFolder> =
        songs.groupBy { File(it.path).parent ?: "" }.map { (path, items) ->
            MusicFolder(
                path = path,
                name = File(path).name.ifBlank { "Unknown Folder" },
                songCount = items.size,
            )
        }.sortedBy { it.name.lowercase() }
}
