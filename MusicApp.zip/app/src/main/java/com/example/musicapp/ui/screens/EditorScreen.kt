package com.example.musicapp.ui.screens

import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RangeSlider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.musicapp.data.model.Song
import com.example.musicapp.editor.AudioEditor
import com.example.musicapp.ui.MusicViewModel
import com.example.musicapp.util.formatDuration
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun EditorScreen(viewModel: MusicViewModel) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var selectedSong by remember { mutableStateOf<Song?>(null) }
    var showPicker by remember { mutableStateOf(false) }
    var startMs by remember { mutableLongStateOf(0L) }
    var endMs by remember { mutableLongStateOf(0L) }
    var exporting by remember { mutableStateOf(false) }

    fun selectSong(song: Song) {
        selectedSong = song
        startMs = 0L
        endMs = song.durationMs.coerceAtLeast(0L)
        showPicker = false
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
    ) {
        Text("Audio Editor", style = MaterialTheme.typography.headlineSmall)
        Text(
            "Trim a song and export a new audio clip. Best results with AAC/M4A sources.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(top = 4.dp, bottom = 16.dp),
        )

        OutlinedButton(onClick = { showPicker = true }, enabled = viewModel.hasPermission) {
            Text(selectedSong?.title ?: "Select song")
        }

        Spacer(Modifier.height(16.dp))

        val song = selectedSong
        if (song == null) {
            Text(
                if (viewModel.hasPermission) "Choose a song to start editing." else "Grant audio permission to edit songs.",
                style = MaterialTheme.typography.bodyMedium,
            )
        } else {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text(song.title, style = MaterialTheme.typography.titleMedium)
                    Text("${song.artist} • ${song.album}", style = MaterialTheme.typography.bodySmall)
                    Text("Duration: ${formatDuration(song.durationMs)}", style = MaterialTheme.typography.bodySmall)
                }
            }

            Spacer(Modifier.height(20.dp))
            Text("Trim range", style = MaterialTheme.typography.titleMedium)
            val duration = song.durationMs.coerceAtLeast(1L)
            RangeSlider(
                value = startMs.toFloat()..endMs.toFloat(),
                onValueChange = { range ->
                    startMs = range.start.toLong().coerceIn(0L, duration)
                    endMs = range.endInclusive.toLong().coerceIn(0L, duration)
                    if (endMs <= startMs) endMs = (startMs + 1000).coerceAtMost(duration)
                },
                valueRange = 0f..duration.toFloat(),
                modifier = Modifier.fillMaxWidth(),
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Start: ${formatDuration(startMs)}", style = MaterialTheme.typography.bodySmall)
                Text("End: ${formatDuration(endMs)}", style = MaterialTheme.typography.bodySmall)
            }
            Text("Length: ${formatDuration((endMs - startMs).coerceAtLeast(0L))}", style = MaterialTheme.typography.bodySmall)

            Spacer(Modifier.height(20.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Button(
                    onClick = { viewModel.playSong(song); viewModel.seekTo(startMs) },
                    enabled = !exporting,
                ) { Text("Preview") }

                Button(
                    onClick = {
                        exporting = true
                        scope.launch {
                            val result = runCatching {
                                withContext(Dispatchers.IO) {
                                    val outName = "${song.title}_trim_${System.currentTimeMillis()}"
                                    AudioEditor.trimAudio(
                                        context = context,
                                        inputPath = song.path,
                                        startMs = startMs,
                                        endMs = endMs,
                                        outputName = outName,
                                    )
                                }
                            }
                            exporting = false
                            result.onSuccess {
                                Toast.makeText(context, "Exported: ${it.outputPath}", Toast.LENGTH_LONG).show()
                            }.onFailure {
                                Toast.makeText(context, "Export failed: ${it.message}", Toast.LENGTH_LONG).show()
                            }
                        }
                    },
                    enabled = !exporting && endMs > startMs,
                ) {
                    if (exporting) {
                        CircularProgressIndicator(modifier = Modifier.height(18.dp), strokeWidth = 2.dp)
                    } else {
                        Text("Export trim")
                    }
                }
            }
        }
    }

    if (showPicker) {
        AlertDialog(
            onDismissRequest = { showPicker = false },
            confirmButton = {},
            title = { Text("Select song") },
            text = {
                LazyColumn {
                    items(viewModel.songs, key = { it.id }) { song ->
                        TextButton(onClick = { selectSong(song) }, modifier = Modifier.fillMaxWidth()) {
                            Text("${song.title} — ${song.artist}", maxLines = 1)
                        }
                    }
                }
            },
            dismissButton = {
                TextButton(onClick = { showPicker = false }) { Text("Close") }
            }
        )
    }
}
