package com.example.musicapp.ui.screens

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.musicapp.ui.MusicViewModel
import com.example.musicapp.ui.components.SongRow

@Composable
fun SongsScreen(viewModel: MusicViewModel) {
    when {
        !viewModel.hasPermission -> PermissionMessage("Audio permission is required to load your songs.")
        viewModel.isLoading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator()
        }
        else -> Column(Modifier.fillMaxSize()) {
            Text(
                text = "Songs (${viewModel.songs.size})",
                style = MaterialTheme.typography.headlineSmall,
                modifier = Modifier.padding(16.dp),
            )
            LazyColumn(modifier = Modifier.fillMaxSize()) {
                items(viewModel.songs, key = { it.id }) { song ->
                    SongRow(song = song, onClick = { viewModel.playSong(song, viewModel.songs) })
                }
            }
        }
    }
}

@Composable
fun PermissionMessage(message: String) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text(
            text = message,
            style = MaterialTheme.typography.bodyLarge,
            modifier = Modifier.padding(24.dp),
        )
    }
}
