package com.example.musicapp.ui.screens

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.musicapp.data.model.MusicFolder
import com.example.musicapp.ui.MusicViewModel
import com.example.musicapp.ui.components.SongRow
import java.io.File

@Composable
fun FoldersScreen(viewModel: MusicViewModel) {
    var selectedFolder by remember { mutableStateOf<MusicFolder?>(null) }

    when {
        !viewModel.hasPermission -> PermissionMessage("Audio permission is required to load folders.")
        viewModel.isLoading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        selectedFolder != null -> {
            val folder = selectedFolder!!
            val folderSongs = viewModel.songs.filter { (File(it.path).parent ?: "") == folder.path }
            Column(Modifier.fillMaxSize()) {
                Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { selectedFolder = null }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                    Spacer(Modifier.width(4.dp))
                    Column {
                        Text(folder.name, style = MaterialTheme.typography.titleLarge)
                        Text("${folder.songCount} songs", style = MaterialTheme.typography.bodySmall)
                    }
                }
                LazyColumn(Modifier.fillMaxSize()) {
                    items(folderSongs, key = { it.id }) { song ->
                        SongRow(song = song, onClick = { viewModel.playSong(song, folderSongs) })
                    }
                }
            }
        }
        else -> Column(Modifier.fillMaxSize()) {
            Text("Folders (${viewModel.folders.size})", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.padding(16.dp))
            LazyColumn(Modifier.fillMaxSize()) {
                items(viewModel.folders, key = { it.path }) { folder ->
                    CategoryRow(
                        title = folder.name,
                        subtitle = "${folder.path} • ${folder.songCount} songs",
                        onClick = { selectedFolder = folder },
                    )
                }
            }
        }
    }
}
