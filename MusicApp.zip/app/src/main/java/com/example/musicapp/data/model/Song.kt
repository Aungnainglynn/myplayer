package com.example.musicapp.data.model

import android.net.Uri

data class Song(
    val id: Long,
    val title: String,
    val artist: String,
    val album: String,
    val albumId: Long,
    val genre: String,
    val durationMs: Long,
    val path: String,
    val folder: String,
    val contentUri: Uri,
    val albumArtUri: Uri,
)
