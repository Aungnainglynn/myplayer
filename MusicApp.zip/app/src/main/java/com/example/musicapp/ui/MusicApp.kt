package com.example.musicapp.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Album
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.musicapp.ui.navigation.AppRoute
import com.example.musicapp.ui.navigation.bottomNavRoutes
import com.example.musicapp.ui.screens.AlbumsScreen
import com.example.musicapp.ui.screens.EditorScreen
import com.example.musicapp.ui.screens.FoldersScreen
import com.example.musicapp.ui.screens.GenresScreen
import com.example.musicapp.ui.screens.PlayerScreen
import com.example.musicapp.ui.screens.SongsScreen

@Composable
fun MusicApp(viewModel: MusicViewModel) {
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentDestination = backStackEntry?.destination

    Scaffold(
        bottomBar = {
            Column {
                viewModel.currentSong?.let { song ->
                    if (currentDestination?.route != AppRoute.Player.route) {
                        NowPlayingBar(
                            title = song.title,
                            artist = song.artist,
                            isPlaying = viewModel.isPlaying,
                            onPlayPause = viewModel::togglePlayPause,
                            onNext = viewModel::next,
                            onOpenPlayer = { navController.navigate(AppRoute.Player.route) },
                        )
                    }
                }
                if (currentDestination?.route != AppRoute.Player.route) {
                    NavigationBar {
                        bottomNavRoutes.forEach { route ->
                            val selected = currentDestination?.hierarchy?.any { it.route == route.route } == true
                            NavigationBarItem(
                                selected = selected,
                                onClick = {
                                    navController.navigate(route.route) {
                                        popUpTo(navController.graph.findStartDestination().id) {
                                            saveState = true
                                        }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                },
                                icon = { Icon(routeIcon(route), contentDescription = route.label) },
                                label = { Text(route.label) },
                            )
                        }
                    }
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = AppRoute.Songs.route,
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
        ) {
            composable(AppRoute.Songs.route) { SongsScreen(viewModel) }
            composable(AppRoute.Albums.route) { AlbumsScreen(viewModel) }
            composable(AppRoute.Genres.route) { GenresScreen(viewModel) }
            composable(AppRoute.Folders.route) { FoldersScreen(viewModel) }
            composable(AppRoute.Editor.route) { EditorScreen(viewModel) }
            composable(AppRoute.Player.route) {
                PlayerScreen(
                    viewModel = viewModel,
                    onBack = { navController.popBackStack() },
                )
            }
        }
    }
}

@Composable
private fun NowPlayingBar(
    title: String,
    artist: String,
    isPlaying: Boolean,
    onPlayPause: () -> Unit,
    onNext: () -> Unit,
    onOpenPlayer: () -> Unit,
) {
    Surface(tonalElevation = 3.dp) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable(onClick = onOpenPlayer)
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyLarge)
                Text(
                    artist,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            IconButton(onClick = onPlayPause) {
                Icon(if (isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow, contentDescription = "Play/Pause")
            }
            IconButton(onClick = onNext) {
                Icon(Icons.Filled.SkipNext, contentDescription = "Next")
            }
        }
    }
}

private fun routeIcon(route: AppRoute) = when (route) {
    AppRoute.Songs -> Icons.Filled.MusicNote
    AppRoute.Albums -> Icons.Filled.Album
    AppRoute.Genres -> Icons.Filled.Category
    AppRoute.Folders -> Icons.Filled.Folder
    AppRoute.Editor -> Icons.Filled.GraphicEq
    AppRoute.Player -> Icons.Filled.MusicNote
}
