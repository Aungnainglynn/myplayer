package com.example.musicapp.data.model

data class Album(
    val id: Long,
    val name: String,
    val artist: String,
    val songCount: Int,
    val artUri: android.net.Uri,
)

data class Genre(
    val name: String,
    val songCount: Int,
)

data class MusicFolder(
    val path: String,
    val name: String,
    val songCount: Int,
)
