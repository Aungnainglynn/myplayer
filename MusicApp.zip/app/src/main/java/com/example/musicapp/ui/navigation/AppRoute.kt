package com.example.musicapp.ui.navigation

sealed class AppRoute(val route: String, val label: String) {
    data object Songs : AppRoute("songs", "Songs")
    data object Albums : AppRoute("albums", "Albums")
    data object Genres : AppRoute("genres", "Genres")
    data object Folders : AppRoute("folders", "Folders")
    data object Editor : AppRoute("editor", "Editor")
    data object Player : AppRoute("player", "Player")
}

val bottomNavRoutes = listOf(
    AppRoute.Songs,
    AppRoute.Albums,
    AppRoute.Genres,
    AppRoute.Folders,
    AppRoute.Editor,
)
