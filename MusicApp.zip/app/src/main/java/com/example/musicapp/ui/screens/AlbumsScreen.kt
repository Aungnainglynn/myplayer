package com.example.musicapp.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.musicapp.data.model.Album
import com.example.musicapp.ui.MusicViewModel
import com.example.musicapp.ui.components.SongRow

@Composable
fun AlbumsScreen(viewModel: MusicViewModel) {
    var selectedAlbum by remember { mutableStateOf<Album?>(null) }

    when {
        !viewModel.hasPermission -> PermissionMessage("Audio permission is required to load albums.")
        viewModel.isLoading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        selectedAlbum != null -> {
            val album = selectedAlbum!!
            val albumSongs = viewModel.songs.filter { it.albumId == album.id }
            Column(Modifier.fillMaxSize()) {
                Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { selectedAlbum = null }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                    Spacer(Modifier.width(4.dp))
                    Column {
                        Text(album.name, style = MaterialTheme.typography.titleLarge)
                        Text("${album.songCount} songs", style = MaterialTheme.typography.bodySmall)
                    }
                }
                LazyColumn(Modifier.fillMaxSize()) {
                    items(albumSongs, key = { it.id }) { song ->
                        SongRow(song = song, onClick = { viewModel.playSong(song, albumSongs) })
                    }
                }
            }
        }
        else -> Column(Modifier.fillMaxSize()) {
            Text("Albums (${viewModel.albums.size})", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.padding(16.dp))
            LazyColumn(Modifier.fillMaxSize()) {
                items(viewModel.albums, key = { it.id }) { album ->
                    CategoryRow(
                        title = album.name,
                        subtitle = "${album.artist} • ${album.songCount} songs",
                        onClick = { selectedAlbum = album },
                    )
                }
            }
        }
    }
}

@Composable
fun CategoryRow(title: String, subtitle: String, onClick: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        Text(title, style = MaterialTheme.typography.bodyLarge)
        Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
