# MusicApp (Android / Kotlin)

A Kotlin Android music player app with library classification and a basic audio editor.

## Features

- **Music library scanning** via `MediaStore`
- **Classification views**:
  - Songs (title-based listing)
  - Albums
  - Genres
  - Folders
- **Playback** using Media3/ExoPlayer with a foreground `MediaSessionService`
- **Now Playing** screen with seek, play/pause, next/previous
- **Audio editor**:
  - Select a song from the library
  - Choose trim start/end range
  - Preview from selected start
  - Export trimmed clip (MPEG-4/M4A output using `MediaExtractor` + `MediaMuxer`)

## Project structure

- `app/src/main/java/com/example/musicapp/data/model` - data models (`Song`, `Album`, `Genre`, `MusicFolder`)
- `app/src/main/java/com/example/musicapp/data/repository` - MediaStore scanning and category builders
- `app/src/main/java/com/example/musicapp/player` - Media3 playback service
- `app/src/main/java/com/example/musicapp/editor` - audio trim/export utility
- `app/src/main/java/com/example/musicapp/ui` - Compose UI, ViewModel, navigation, screens
- `app/src/main/AndroidManifest.xml` - permissions and service/activity declarations

## Build & run

1. Open this folder in **Android Studio** (Hedgehog+ recommended).
2. Let Gradle sync.
3. Run on an Android device/emulator (API 24+).
4. Grant audio/media permissions when prompted.

## Notes / limitations

- Genre mapping uses `MediaStore.Audio.Genres`; availability depends on device/media index.
- Audio editor trim/export works best with compatible audio tracks (AAC/M4A/MP4). Some formats may fail to export depending on codec/container.
- On Android 10+, direct file path access can be restricted in some cases; the app uses MediaStore metadata and attempts export to app storage + MediaStore.
- This is a starter implementation intended to be extended (waveform UI, fade effects, format conversion, playlists, search, etc.).
